(async () => {
  console.log('Załadowano rozszerzenie Show Top Offers');
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
  for (const contentScript of chrome.runtime.getManifest().content_scripts) {
    for (const tab of await chrome.tabs.query({ url: contentScript.matches })) {
      try {
        chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: contentScript.css
        });
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: contentScript.js
        });
        console.log('odświeżono skrypty na otwartych stronach.');					
      } catch (error) {
        console.log('Błąd! Nie udało się odświeżyć skryptów.');
      }
    }
  }
})();

async function handleBackgroundFetchPartially(request) {
	let response = await fetch(request.url);

  if (response.status === 403) {
    console.log('Too many requests, error 403');
		return Promise.reject('tooManyRequests');
  }
			
	if (!response.body) {
		return Promise.reject('Nie udało się pobrać aukcji.');
	}

	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let partialContent = '';
	const regex = new RegExp('article class', 'g');
	const captchaRegex = new RegExp('captchaPlaceholder', 'g');
	const humanVerificationRegex = new RegExp('Potwierdź, że jesteś człowiekiem', 'g');
	let matches;
	let matchesFound = 0;

	while (true) {
		const { done, value } = await reader.read();
		const chunkText = decoder.decode(value, { stream: true });
		partialContent += chunkText;
		matches = partialContent.match(regex);
		if (matches) {
			if (matches.length > 2) {
				reader.cancel();
				const finalRegex = new RegExp(`-${request.offerId}" rel`, 'g');
				matches = partialContent.match(finalRegex);
				if (matches) {
					matchesFound = matches.length;
				}
				break;
			}
		} else {
			if (partialContent.match(captchaRegex) || partialContent.match(humanVerificationRegex)) {
				console.log('Too many requests, capcha verification needed');
				return Promise.reject('tooManyRequests');
			}
		}
		if (done) {
			break;
		}
	}
	const isTopOffer = (matchesFound > 1 ? 'top' : 'normal');
	return Promise.resolve(isTopOffer);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
		case 'backgroundFetchPartially': {
			return await handleBackgroundFetchPartially(request);
		}
  }
}

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Show-top-offers/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Show-top-offers' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		} else {
			console.log(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error instanceof Error ? error.message : error}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Show-top-offers' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				console.log(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();