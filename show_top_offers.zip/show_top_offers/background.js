async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		async function setDefaultValues() {
			try {
				await saveDataToLocalStorage({
					showTopOffersEnabled: true
				});
			} catch (error) {
				return Promise.reject(`Podczas inicjalizacji domyślnych parametrów wystąpił błąd. ${error instanceof Error ? error.message : error}`);
			}
		}
		setDefaultValues().catch(error => {
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Błąd rozszerzenia Pokaż Top Oferty', message: (error instanceof Error ? error.message : error)});
		})
	}
});

(async () => {
  console.log('Załadowano rozszerzenie Show Top Offers');
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

  for (const contentScript of chrome.runtime.getManifest().content_scripts) {
    for (const tab of await chrome.tabs.query({ url: contentScript.matches })) {
      try {
        chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: contentScript.css
        });
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: contentScript.js
        });
        console.log('Odświeżono skrypty na otwartych stronach');					
      } catch (error) {
        console.log('Błąd! Nie udało się odświeżyć skryptów.');
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Błąd rozszerzenia Pokaż Top Oferty', message: `Nie udało się odświeżyć skryptów. ${(error instanceof Error ? error.message : error)}` });
      }
    }
  }
})();

async function handleBackgroundFetchPartially(request) { 
	switchUserAgent(Math.floor(Math.random() * 4));
	let response = await fetch(request.url);

  if (response.status === 403 || response.status === 429) {
    console.log('Too many requests, error 403/429');
		return Promise.reject('tooManyRequests');
  }
			
	if (!response.body) {
		return Promise.reject('Nie udało się pobrać aukcji.');
	}

	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let partialContent = '';
	const regex = new RegExp('article class', 'g');
	const captchaRegex = new RegExp('captchaPlaceholder', 'g');
	const humanVerificationRegex = new RegExp('Potwierdź, że jesteś człowiekiem', 'g');
	let matches;
	let matchesFound = 0;

	while (true) {
		const { done, value } = await reader.read();
		const chunkText = decoder.decode(value, { stream: true });
		partialContent += chunkText;
		matches = partialContent.match(regex);
		if (matches) {
			if (matches.length > 2) {
				reader.cancel();
				const finalRegex = new RegExp(`-${request.offerId}" rel`, 'g');
				matches = partialContent.match(finalRegex);
				if (matches) {
					matchesFound = matches.length;
				}
				break;
			}
		} else {
			if (partialContent.match(captchaRegex) || partialContent.match(humanVerificationRegex)) {
				console.log('Too many requests, capcha verification needed');
				return Promise.reject('tooManyRequests');
			}
		}
		if (done) {
			break;
		}
	}
	const isTopOffer = (matchesFound > 1 ? 'top' : 'normal');
	return Promise.resolve(isTopOffer);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
		case 'backgroundFetchPartially': {
			return await handleBackgroundFetchPartially(request);
		}
  }
}

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Show-top-offers/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Show-top-offers' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		} else {
			console.log(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error instanceof Error ? error.message : error}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Show-top-offers' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				console.log(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('Brak pliku z informacją o aktualizacji');
	}
})();

function switchUserAgent(ruleset) {
	switch (ruleset) {
		case 0: {
			chrome.declarativeNetRequest.updateEnabledRulesets({
				enableRulesetIds: ['ruleset_0'], 
				disableRulesetIds: ['ruleset_1', 'ruleset_2', 'ruleset_3']
			});
			break;
		}

		case 1: {
			chrome.declarativeNetRequest.updateEnabledRulesets({
				enableRulesetIds: ['ruleset_1'], 
				disableRulesetIds: ['ruleset_0', 'ruleset_2', 'ruleset_3']
			});
			break;
		}

		case 2: {
			chrome.declarativeNetRequest.updateEnabledRulesets({
				enableRulesetIds: ['ruleset_2'], 
				disableRulesetIds: ['ruleset_0', 'ruleset_1', 'ruleset_3']
			});
			break;
		}

		case 3: {
			chrome.declarativeNetRequest.updateEnabledRulesets({
				enableRulesetIds: ['ruleset_3'], 
				disableRulesetIds: ['ruleset_0', 'ruleset_1', 'ruleset_2']
			});
			break;
		}
	}
}