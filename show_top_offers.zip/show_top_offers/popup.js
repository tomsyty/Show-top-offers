async function saveDataToLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.set(data, () => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true);
		});
	});
}

async function readDataFromLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(data, (result) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result);
		});
	});
}

document.addEventListener('DOMContentLoaded', async () => {
  const workEnabled = document.getElementById('workEnabled');
  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['showTopOffersEnabled']);
  } catch (error) {
    toastMessage(`Błąd! Nie udało się wczytać stanu działania rozszerzenia. ${error instanceof Error ? error.message : error}`);
    return;
  }

  if (readedValue.showTopOffersEnabled !== undefined) {
    workEnabled.checked = (readedValue.showTopOffersEnabled === true ? true : false);
  }
  
  workEnabled.addEventListener('change', async (e) => {
    try {
			await saveDataToLocalStorage({ showTopOffersEnabled: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zapisać stanu działania rozszerzenia. ${error instanceof Error ? error.message : error}`);
			return;
		}
    toastMessage('Zapisano');
  });
});