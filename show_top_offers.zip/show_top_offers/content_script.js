async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(data, (result) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result);
		});
	});
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetchPartially(url, offerId) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'backgroundFetchPartially',
      url: url,
      offerId: offerId
    }, (response) => {
      if (response.success) {
        resolve(response.result);
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt showTopOffers');
  let readedValue;
  let offers;
  try {
    readedValue = await readDataFromSessionStorage(['topOffers']);
  } catch (error) {
    toastMessage('Błąd! Nie udało się wczytać listy top ofert z pamięci');
  }

  if (readedValue && Object.keys(readedValue).length) offers = readedValue['topOffers'];
  else offers = {};  

	awaitOffersTable(offers);
});

async function awaitOffersTable(offers) {
  let enabled;
  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['showTopOffersEnabled']);
    enabled = readedValue.showTopOffersEnabled;
  } catch (error) {
    toastMessage('Błąd! Nie udało się sprawdzić stanu działania rozszerzenia. Domyślnie zostaje ono włączone.');
    enabled = true;
  }

  console.log(`Pobieranie aukcji jest ${enabled ? 'włączone' : 'wyłączone'}`);
  
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable,
    enabled: enabled
	}

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	parameters.environment = environment;

	if (offersTable === null) {
		const pageObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
            pageObserver.takeRecords();
						pageObserver.disconnect();
						const delay = t => new Promise(resolve => setTimeout(resolve, t));
						await delay(100);
						await awaitOffersTable(offers);
					}
				}
			}
		});
		pageObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				const delay = t => new Promise(resolve => setTimeout(resolve, t));
				await delay(100);
				await awaitOffersTable(offers);
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
      await getAuctions(parameters, offers);
		}
		urlObserver.observe(document, { subtree: true, childList: true });

    const offersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          if (Array.from(mutation.addedNodes).filter(element => element.nodeName === 'TR' && element.dataset.cy !== undefined)?.length) {
            offersTableObserver.takeRecords();
            offersTableObserver.disconnect();
            await getAuctions(parameters, offers);
            offersTableObserver.observe(parameters.offersTable, { subtree: true, childList: true });
          }
        }
      }	
    });
    offersTableObserver.observe(parameters.offersTable, { subtree: true, childList: true });
	}	
}

async function getAuctions(parameters, offers) {
	let offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="top_${element.dataset.cy}"]`) === null);
	
	if (!offersList.length) {
		return;
	}

  let offersToGet = [];
  let topOfferState;
  let offerId;
	for (const offer of offersList) {
    offerId = offer.dataset.cy;
		if (!offers[offerId]) {
      if (!parameters.enabled) continue;
      offers[offerId] = null;
      try {
        await saveDataToSessionStorage({
          topOffers: offers
        });
      } catch (error) {
        toastMessage('Błąd! Nie udało się zapisać danych w pamięci.');
        return;
      }
      offersToGet.push(offerId);
      if (!offer.querySelector(`div[data-id="top_${offerId}"]`)) {
        const badge = `<div data-id="top_${offerId}" class="unknownOfferBadge">TOP</div>`;
        offer.children[5].insertAdjacentHTML('beforeend', badge);
      }
    } else {
      if (offer === null) continue;
      let badge = offer.querySelector(`div[data-id="top_${offerId}"]`);
      if (offers[offerId] === 'top') {
        if (badge === null) {
          badge = `<div data-id="top_${offerId}" class="topOfferBadge">TOP</div>`;
          offer.children[5].insertAdjacentHTML('beforeend', badge);
        } else {
          badge.innerText = 'TOP';
          badge.classList = 'topOfferBadge';
        }
      } else {
        if (badge === null) {
          badge = `<div data-id="top_${offerId}" class="unknownOfferBadge">NOR</div>`;
          offer.children[5].insertAdjacentHTML('beforeend', badge);
        } else {
          badge.innerText = 'NOR';
          badge.classList = 'unknownOfferBadge';
        }
      }
    }
	}
	
	while (offersToGet.length > 0) {
    if (!parameters.enabled) break;
		const offerId = offersToGet.shift();
		const offer = parameters.offersTable.querySelector(`tr[data-cy="${offerId}"]`);
		if (offer === null) continue;
		const productIdHrefElement = offer.querySelector('a[href*="/changes-in-product-catalogue/report/"]');
		if (productIdHrefElement === null) continue;
		const productId = productIdHrefElement.href.slice(productIdHrefElement.href.lastIndexOf('/') + 1);
    if (!offers[offerId]) {
      try {
        topOfferState = await checkTopOffer(offerId, productId, parameters);
        offers[offerId] = topOfferState;
        try {
          await saveDataToSessionStorage({
            topOffers: offers
          });
        } catch (error) {
          toastMessage('Błąd! Nie udało się zapisać danych w pamięci.');
          return;
        }
        
        let badge = offer.querySelector(`div[data-id="top_${offerId}"]`);
        if (topOfferState === 'top') {
          if (badge === null) {
            const badge = `<div data-id="top_${offerId}" class="topOfferBadge">TOP</div>`;
            offer.children[5].insertAdjacentHTML('beforeend', badge);
          } else {
            badge.innerText = 'TOP';
            badge.classList = 'topOfferBadge';
          }
        } else {
          if (badge === null) {
            badge = `<div data-id="top_${offerId}" class="unknownOfferBadge">NOR</div>`;
            offer.children[5].insertAdjacentHTML('beforeend', badge);
          } else {
            badge.innerText = 'NOR';
            badge.classList = 'unknownOfferBadge';
          }
        }
      } catch (error) {
        parameters.enabled = false;
        if (error === 'tooManyRequests') {
          toastMessage('Błąd! Przekroczono limit zapytań. Wykonaj czynności opisane na stronie rozszerzenia <a href="https://github.com/tomsyty/Show-top-offers/blob/main/README.md#czyszczenie-pami%C4%99ci-podr%C4%99cznej-i-cookies-w-razie-wyst%C4%85pienia-blokady-strony">(kliknij tutaj aby ją otworzyć)</a> aby odblokować stronę allegro.pl. Anulowano dalsze pobieranie aukcji.');
        } else {
          toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
        }
        try {
          await saveDataToLocalStorage({ showTopOffersEnabled : false });
        } catch (error) {
          toastMessage('Błąd! Nie udało się zapisać stanu działania rozszerzenia.');
        }

        const unprocessedOffers = parameters.offersTable.querySelectorAll('div.unknownOfferBadge');
        unprocessedOffers.forEach(element => { if (element.innerText === 'TOP') element.remove() });
        return;
      }
    }
	}

  if (!parameters.enabled) return;

  const delay = t => new Promise(resolve => setTimeout(resolve, t));
	await delay(1000);

  offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="top_${element.dataset.cy}"]`) === null);
  if (offersList.length) {
    return await getAuctions(parameters, offers);
  }
}
		
async function checkTopOffer(offerId, productId, parameters) {
  const url =  `https://allegro.pl${parameters.environment}/produkt/${productId}`;
  let response;
  const randomDelay = Math.floor(5000 + (Math.random() * 5000));
  try {
    response = await backgroundFetchPartially(url, offerId);
  } catch (error) {
    console.log(error instanceof Error ? error.message : error);
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    await delay(randomDelay);
    return Promise.reject(error instanceof Error ? error.message : error);
  }
  console.log(`auction ${offerId} is ${response} offer`);
  const delay = t => new Promise(resolve => setTimeout(resolve, t));
	await delay(randomDelay);
  return Promise.resolve(response);
}